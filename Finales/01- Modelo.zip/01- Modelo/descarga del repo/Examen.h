#ifndef EXAMEN_H
#define EXAMEN_H


class Examen
{
    public:

    void Punto3();
    private:
};

#endif // EXAMEN_H
